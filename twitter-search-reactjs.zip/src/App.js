import React from 'react';
import logo from './logo.svg';
import './App.css';
import Home from './components/home';

function App() {
  return (
    <div  style={{padding :'20px'}}>
      <Home/>
    </div>
  );
}

export default App;
